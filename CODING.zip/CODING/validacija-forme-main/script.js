let inputs = document.querySelectorAll(`input`)
let errors = {

    "Ime_prezime":[],
    "Korisnicko_ime":[],
    "email":[],
    "lozinka":[],
    "ponovi_lozinku":[],
}

inputs.forEach(element => {
    element.addEventListener(`change`, e => {
        let currentInput = e.target
        let inputValue = currentInput.value
        let inputName = currentInput.getAttribute(`name`)

        if(inputValue.length>4) {
            console.log(`top`)
        } else {
            errors[inputName] = [`polje ne moze imati vise od pet karaktera`]
        }

        populateErrors(errors)
        document.querySelector(`div`).innerHTML = `<ul><li>${errors[inputName][0]}</li></ul>`
    })
})

const populateErrors = (errors) => {
    console.log(errors)

    for(let key in objects.keys(errors)) {
        let input = document,querySelector(`input[name="${key}]`)
        let parentElement = input.parentElement
        let errorsElement = document.createElement(`ul`)
        parentElement.appendChild(errorsElement)

        errors[key].forEach(() => {
            let li = document.createElement(`li`)
            li.innerText = error
            errorsElement.appendChild(li)
        })
    }
}