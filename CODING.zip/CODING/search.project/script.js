function search () {
  var search = document.querySelector('#search-input')
  console.log(search)
  
  
  xmlhttp = new XMLHttpRequest()
  xmlhttp.open(`GET`, `https://damir-project-default-rtdb.europe-west1.firebasedatabase.app/.json`, true)
  xmlhttp.onreadystatechange = function () {
  if(this.readyState == 4) {
      console.log(this.status)
      //console.log(JSON.parse(this.responseText)) //prikazujemo u konzoli nasu bazu podataka odnosno niz objekata

      let product = JSON.parse(this.responseText) 
     
      const mergedArrays = product.cartSneakers.concat(product.cartHoodies, product.cartSweaters, product.cartTshirts)

      function searchItems(array, name) {
        if (!array || !Array.isArray(array)) {
          return [];
        }
      
        return array.filter(item => item && item.name === name);
      }
      
      const searchResult = searchItems(mergedArrays, search.value);
      
      console.log(searchResult);

      console.log(searchResult[0].name)
   //prvi if
      if(search.value.includes(`Sweater`)) {

        xmlhttp = new XMLHttpRequest()
        xmlhttp.open(`GET`, `https://damir-project-default-rtdb.europe-west1.firebasedatabase.app/kategorie.json`, true)
        xmlhttp.onreadystatechange = function () {
          if(this.readyState == 4) {
            console.log(JSON.parse(this.responseText))
            let link = JSON.parse(this.responseText)
            console.log(link[2].indexLink)
            let result = document.querySelector(`#result-container`)
            let html = ``
            html = `<a href="${link[2].indexLink}"><p>Go in cart</p></a>`
            result.innerHTML = html
          }
        }

        xmlhttp.send()


        

        
      }
//else
    
      else if(search.value.includes(`Nike`)) {
        xmlhttp = new XMLHttpRequest()
        xmlhttp.open(`GET`, `https://damir-project-default-rtdb.europe-west1.firebasedatabase.app/kategorie.json`, true)
        xmlhttp.onreadystatechange = function () {
          if(this.readyState == 4) {
            console.log(JSON.parse(this.responseText))
            let link = JSON.parse(this.responseText)
            console.log(link[0].indexLink)
            let result = document.querySelector(`#result-container`)
            let html = ``
            html = `<a href="${link[0].indexLink}"><p>Go in cart</p></a>`
            result.innerHTML = html
          }
        }

        xmlhttp.send()


      }

      //else

      

      else if(search.value.includes(`Hoodie`)) {
        xmlhttp = new XMLHttpRequest()
        xmlhttp.open(`GET`, `https://damir-project-default-rtdb.europe-west1.firebasedatabase.app/kategorie.json`, true)
        xmlhttp.onreadystatechange = function () {
          if(this.readyState == 4) {
            console.log(JSON.parse(this.responseText))
            let link = JSON.parse(this.responseText)
            console.log(link[1].indexLink)
            let result = document.querySelector(`#result-container`)
            let html = ``
            html = `<a href="${link[1].indexLink}"><p>Go in cart</p></a>`
            result.innerHTML = html
          }
        }

        xmlhttp.send()

      }

      else if (search.value.includes(`T-shirt`)) {
        xmlhttp = new XMLHttpRequest()
        xmlhttp.open(`GET`, `https://damir-project-default-rtdb.europe-west1.firebasedatabase.app/kategorie.json`, true)
        xmlhttp.onreadystatechange = function () {
          if(this.readyState == 4) {
            console.log(JSON.parse(this.responseText))
            let link = JSON.parse(this.responseText)
            console.log(link[3].indexLink)
            let result = document.querySelector(`#result-container`)
            let html = ``
            html = `<a href="${link[3].indexLink}"><p>Go in cart</p></a>`
            result.innerHTML = html
          }
        }

        xmlhttp.send()

      }

    
      

      

      

      

      
       
      


      


      
      
      
      
      


      
    





    
    
    

    }

  }
        



  

   




xmlhttp.send()










}





  
  