xmlhttp = new XMLHttpRequest()

xmlhttp.open(`GET`, `https://damir-project-default-rtdb.europe-west1.firebasedatabase.app/cartSweaters.json`, true)
xmlhttp.onreadystatechange = function () {

    let products = JSON.parse(this.responseText)
    let productsContainer = document.querySelector(`.items`)
    let html = ``
    if(this.readyState == 4) {
        console.log(this.status)
        console.log(JSON.parse(this.responseText))

        for(let i = 0; i<products.length; i++) {
            html += `<div class="single-item">
            <img src="${products[i].img}">
            <div class="si-content">
                <h3>${products[i].name}</h3>
                <p class="price">${products[i].price}</p>
            </div>
            <div class="actions">
                <input type="number" name="quantity" value="0" min="0">
                <button onclick="addToCart(this)">Dodaj</button>
            </div>
        </div>`

            productsContainer.innerHTML = html
        }






        
    }  


}

        
    



xmlhttp.send()


let allTotal = 0;//nova varijabla za konacni total zbir pojedicacnih totala



function addToCart (element) {
    let mainEl = element.closest(`.single-item`);
    let price = mainEl.querySelector(`.price`).innerText;
    let name = mainEl.querySelector(`h3`).innerText;
    let quantity = mainEl.querySelector(`input`).value
    let carItems = document.querySelector (`.cart-items`)//dohvacamo pomocu jsa prazan div iz htmla sa cart-items klasom
    let totalItems = document.querySelector(`.total`)//dohvacamo pomocu jsa prazan div total iz htmla sa total klasom
    console.log(quantity)
    

    if (parseInt(quantity)>0) {//uslov kada se pocinju ispisivati novi elementi u korpi pored

        

        //prebacivanje price-a zbog $ u broj i racunanje totala za korpu.//1:39;7
        
        price = parseInt(price)
        let total = price*parseInt(quantity)
        console.log(price)
        console.log(quantity)
        
        allTotal += total;//stavljanje da se na Alltotal  varijablu dodaje i sabiraju pojedinacni totali
        //innerHtml od dohvacenog carItems (pomocu querySelectora) nakon sto stisnemo button da pokrenemo funkciju
        carItems.innerHTML+=`<div class="cart-single-item">
                            <h3>${name}</h3>
                            <p>$${price} x ${quantity} = $<span>${total}</span></p>
                            <button onclick="removeFromCart(this)" class="remove-item">Ukloni</button>
                            </div>
                            `//sredili smo pomocu htmla da izgleda urednije,ubacili div sa klasom koja ima display flex i dodali h i p sa konatenacijom
                            //dodana clasa u button i onclick neka funkcija pomocu koje cemo removati a koju cemo naknadno napisati ispod addToCart funkcije
        totalItems.innerText = `Total $${allTotal}`
                            
                        
        element.innerText = `Dodato`//kad uslov prodje innerText buttona se mijenja u `dodato`

        element.setAttribute (`disabled`, `true`) // dodavanje atributa nakon sto uslov prodje buttonu, da bude disabled i true

        



        

    } else {
        alert(`dodaj kolicinu`)//alert pop up koji uskoci ako se desi `else` odnosno glavni uslov se ne ispuni
    }



    

    
}

function removeFromCart (element) {//nova funkcija za uklanjanje elemenata iz korpe ciji smo onclick staviti na button(koji smo dodali gore u div koji smo dodali)
   
    let mainEl = element.closest(`.cart-single-item`)//kreiranje nove varijable koja znaci da uzimamo najblizi parent od buttona u kojoj je ova funkcija
    let price = mainEl.querySelector(`p span`).innerText //uzeli smo p i span da dobijemo pojedinacni total koji cemo oduzeti od citavog totala
    let name = mainEl.querySelector (`h3`) //uzeli smo h3 iz pocetnog diva
    let vegetables = document.querySelectorAll(`.single-item`) //uzeli smo sve divove povrca
    price=parseInt(price)
    allTotal -= price//koristenje dekrementa da se oduzima pojedinacni total od citavog totala
    mainEl.remove()//metoda za brisanja tog diva kojeg smo uzeli
    document.querySelector('.total').innerText = `Total: ${allTotal}`



    



}
